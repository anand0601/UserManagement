import { Component, OnInit } from '@angular/core';
import { IUser, User } from './user';
import { UserService } from './user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

 _listFilter:string;
 get listFilter():string{
   return this._listFilter;
 }
 set listFilter(value:string){
   this._listFilter = value;
   this.filteredUsers = this.listFilter? this.performFilter(this.listFilter): this.users;
 }

 errorMessage:string;
 users:IUser[] = [];
 filteredUsers:IUser[];
 selectedUser:IUser;
 newUser:User;

  constructor(private userService:UserService) {
    
   }

  ngOnInit() {
    this.newUser= {age:0,name:null,date:null};
    this.getUsers();
  }

  getUsers(){
    this.userService.getUsers().subscribe(
      users=>{
        this.users = users;
        this.filteredUsers = this.users;
      }
    );
  }

  performFilter(filterBy:string): IUser[]{
    filterBy = filterBy.toLocaleLowerCase();
    return this.users.filter((user:IUser)=>
    user.name.toLocaleLowerCase().indexOf(filterBy) !== -1);

  }

  onselect(selectedUser:IUser){
    this.selectedUser = selectedUser;
  }

  createNewUser(newUser:IUser){
    this.userService.createUser(newUser).subscribe(
      (error:any)=> this.errorMessage = <any>error
    );

    this.getUsers();
    
  }

}
