import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { IUser } from './user';
import{ catchError, tap, filter, map, find} from 'rxjs/operators';
 
@Injectable()
export class UserService {

private userAPIUrl = "https://localhost:44361/api/";

  constructor(private http: HttpClient) { }

  getUsers(): Observable<IUser[]>{
    return this.http.get<IUser[]>(this.userAPIUrl + 'users').pipe(
      tap(data=> console.log('All Users:'+JSON.stringify(data))),
     catchError(this.handleError)
    );
  }

  createUser(newUser:IUser):Observable<IUser>{
    const header = new HttpHeaders({'Content-Type':'application/json'});
    return this.http.post<IUser>(this.userAPIUrl + 'users',newUser,{headers:header});
  }

private handleError(err:HttpErrorResponse){

  return Observable.throw(err.error.message);
}

}
