export interface IUser{
    age:number;
    name:string;
    date:Date;
}

export class User implements IUser{
    age:number;
    name:string;
    date:Date;
}