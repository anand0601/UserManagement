﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAPI.DataServices
{
    public interface IService<T>
    {
        IEnumerable<T> GetAll();

        void Add(T t);
    }
}
