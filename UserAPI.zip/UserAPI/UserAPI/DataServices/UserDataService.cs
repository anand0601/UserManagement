﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserAPI.Models;

namespace UserAPI.DataServices
{
    public class UserDataService : IService<UserModel>
    {
        private List<UserModel> users;
        public UserDataService()
        {
            users = new List<UserModel>()
            {
                new UserModel(){ Name = "Peldi", Age=37, Date = DateTime.Now},
                new UserModel(){ Name = "Lior", Age=34, Date = DateTime.Now},
                new UserModel(){ Name = "Patata", Age=37, Date = DateTime.Now},
                new UserModel(){ Name = "Val", Age=18, Date = DateTime.Now},
                new UserModel(){ Name = "Shakshouka", Age=6, Date = DateTime.Now},
                new UserModel(){ Name = "Jachnun", Age=15, Date = DateTime.Now}

            };
        }

        public void Add(UserModel newUser)
        {
            users.Add(newUser);
        }

        public IEnumerable<UserModel> GetAll()
        {
            return this.users;
        }
    }
}
